
  <footer>
    <div class="container">
      <div class="col-lg-12">
        <p>Copyright © 2036 Syncbas_</p>
      </div>
    </div>
  </footer>
