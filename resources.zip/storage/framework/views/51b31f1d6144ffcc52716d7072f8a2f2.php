
  <footer>
    <div class="container">
      <div class="col-lg-12">
        <p>Copyright © 2036 Syncbas_</p>
      </div>
    </div>
  </footer>
<?php /**PATH E:\tiketing\resources\views/layout/footer.blade.php ENDPATH**/ ?>